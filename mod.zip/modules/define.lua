
-- BEE PRODUCE & CRAFTABLE DRINK

function define_boba()
    api_define_item({
        id = "boba",
        name = "Honey Boba",
        category = "Resource",
        tooltip = "Tastes as sweet as it smells! Makes a delicious drink when combined with Apicola.",
        shop_sell = 20,
        bee_lore = "A delicacy found only from the Slippery Bee.",
      }, "sprites/boba.png")
    end

    function define_boba_drink( ... )
      api_define_item({
        id = "boba_drink",
        name = "Honey Boba Drink",
        category = "Resource",
        tooltip = "A refreshing beverage great for warm days. Sold for Rubees.",
        shop_sell = 30,
    }, "sprites/boba_drink.png")

recipe = {
    {item = "definitely_a_bee_boba", amount = 1},
    {item = "bottle", amount = 1}
}
api_define_recipe("t1","definitely_a_bee_honey_boba_drink",
    recipe)
    end

-- BEE

function define_slippery_bee()
    bee_def = {
        id = "slippery_bee",
        title = "Slippery",
        latin = "Apis Piscis",
        hint = "Something's fishy about this bee...",
        desc = "Definitely a bee; there's no way it's anything else. Often found gliding over large areas of water, this bee is easily recognized by the teal shine of its body. It's the perfect addition to any apiarist's collection (even though in one part of the world, it's classified as a 'fish' by law).",
        lifespan = {"Normal"},
        productivity = {"Normal"},
        fertility = {"Fecund"},
        stability = {"Pure"},
        behaviour = {"Diurnal"},
        climate = {"Temperate"},
        rainlover = true,
        snowlover = false,
        grumpy = false,
        produce = "definitely_a_bee_boba",
        chance = 100,
        bid = "B0",
        tier = "4",
        requirement = ""
    }
    api_define_bee(bee_def, 
    "sprites/slippery_item.png", "sprites/slippery_shiny.png", 
    "sprites/slippery_hd.png",
    {r=100, g=100, b=100},
    "sprites/slippery_mag.png",
    "It Can Fly!",
    "It's a bird, it's a plane, it's... The Slippery Bee! Thanks to the efforts of one amazing beekeeper, this fi- er, bee, has seen an amazing increase in population. Keep rocking on, you shinging star, you!"
  )
end

-- BEEHIVE GLOVES & RECIPE

function define_antislip_gloves()
        api_define_item({
            id = "antislip_gloves",
            name = "Anti-Slip Gloves",
            category = "Tool",
            tooltip = "Made with state-of-the-art, anti-slip material. Great for catching the slickest of bees.",
            shop_key = true,
            durability = 1000,
            singular = true
        }, "sprites/antislip_gloves.png")
        
         recipe = {
            {item = "glue", amount = 10},
            {item = "waterproof", amount = 10}
        }
        api_define_recipe("t1", "definitely_a_bee_antislip_gloves", recipe)
    end



-- HIVE                    
    
function define_bee_house()
    api_define_object({
        id = "house",
        name = "Bee House",
        category = "Resource",
        tooltip = "A weird hive found floating on the water.",
        shop_sell = 0,
        aquatic = true,
        tools = {"mouse1", "hammer1"},
        placeable = true,
        place_water = true,
      }, "sprites/bee_house.png")


end

-- MOD WORKBENCH

function define_workbench()
    api_define_workbench("Definitely a Bee", {t1 = "Only Tab"})

end
